/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { QrCode, ShieldCheck, Mail, Smartphone, ArrowRight, UserCheck, AlertTriangle, MessageSquare, Car, Sparkles, Navigation } from 'lucide-react';

interface LandingPageProps {
  onStart: () => void;
  onLogin: () => void;
  onSimulateScan: (qrId: string) => void;
}

export default function LandingPage({ onStart, onLogin, onSimulateScan }: LandingPageProps) {
  // Stagger animation helpers
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.15 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6, ease: [0.16, 1, 0.3, 1] }
    }
  };

  return (
    <div id="landing-container" className="bg-slate-50 text-slate-900 font-sans min-h-screen selection:bg-indigo-600 selection:text-white">
      {/* Dynamic Nav-Rail */}
      <nav className="border-b border-slate-200 bg-white/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="text-indigo-600 font-black text-2xl tracking-tighter">
              AUTOSCAN<span className="text-slate-400 font-medium">V1</span>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <button
              id="nav-login-btn"
              onClick={onLogin}
              className="text-slate-500 hover:text-slate-900 text-sm font-semibold transition-all"
            >
              Sign In
            </button>
            <button
              id="nav-start-btn"
              onClick={onStart}
              className="px-5 py-2 bg-indigo-600 text-white rounded-lg text-sm font-bold hover:bg-indigo-700 transition-all shadow-sm cursor-pointer"
            >
              Go to Dashboard
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <header className="relative bg-white pt-20 pb-24 md:pt-28 md:pb-32 overflow-hidden border-b border-slate-250">
        <div className="max-w-5xl mx-auto px-6 text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-1.5 px-3 py-1 bg-slate-105 text-indigo-750 rounded-full font-mono text-xs font-black uppercase tracking-wider mb-6 border border-slate-200"
          >
            <Sparkles size={12} className="text-indigo-600 animate-pulse" />
            <span>Vehicle QR Tags v1 workspace</span>
          </motion.div>
          <motion.h1
            initial={{ opacity: 0, y: 25 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="font-display text-4xl sm:text-5xl md:text-6xl font-black text-slate-900 leading-[1.05] tracking-tighter max-w-3xl mx-auto uppercase"
          >
            Connect with your vehicle, <br />
            <span className="text-indigo-600 font-light">without revealing your number.</span>
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="mt-6 text-slate-500 text-base sm:text-lg md:text-xl leading-relaxed max-w-2xl mx-auto font-medium"
          >
            Stick an elegant, high-impact QR tag on your windshield. If your car is wrongly parked or has an emergency, bystanders can alert you securely. Private, quick, and built for neighborhoods.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-3"
          >
            <button
              id="hero-dashboard-btn"
              onClick={onStart}
              className="w-full sm:w-auto px-6 py-3.5 bg-indigo-600 text-white rounded-xl font-bold text-sm hover:bg-indigo-700 transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer uppercase tracking-wider"
            >
              Get Started Free <ArrowRight size={16} />
            </button>
            <a
              href="#interactive-demo-hub"
              className="w-full sm:w-auto px-6 py-3.5 border border-slate-250 bg-slate-50 hover:bg-slate-100 text-slate-700 rounded-xl font-bold text-sm transition-all flex items-center justify-center uppercase tracking-wider"
            >
              Try Scanned Demo
            </a>
          </motion.div>
        </div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[300px] bg-indigo-50 rounded-full blur-[120px] opacity-35 -z-10"></div>
      </header>

      {/* Interactive Bystander Scanner Sandbox cockpit */}
      <section id="interactive-demo-hub" className="py-16 bg-slate-100/50 border-b border-slate-200">
        <div className="max-w-4xl mx-auto px-6">
          <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-sm">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="max-w-md">
                <span className="text-[10px] bg-indigo-600 text-white font-mono px-2 py-0.5 rounded font-black tracking-widest uppercase inline-block mb-3">
                  Interactive Demo Area
                </span>
                <h3 className="font-display text-2xl font-black text-slate-900 uppercase tracking-tight">
                  Simulate QR Scanner
                </h3>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  Experience how it works for a passerby immediately without needing a smartphone scanner! Select a preset registered tag to view its action form, or write customizable mock scenarios.
                </p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 shrink-0">
                <button
                  onClick={() => onSimulateScan('QR-8A3F')}
                  className="p-3 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl text-center group transition-all text-slate-800 cursor-pointer"
                >
                  <Car size={16} className="mx-auto text-indigo-600 mb-1" />
                  <span className="font-mono text-[10px] font-bold block text-slate-400">Tesla Model 3</span>
                  <span className="font-display text-xs font-bold block text-slate-900 group-hover:underline">Scan QR-8A3F</span>
                </button>
                <button
                  onClick={() => onSimulateScan('QR-9K2L')}
                  className="p-3 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl text-center group transition-all text-slate-800 cursor-pointer"
                >
                  <Car size={16} className="mx-auto text-slate-800 mb-1" />
                  <span className="font-mono text-[10px] font-bold block text-slate-400">BMW M4 Coupe</span>
                  <span className="font-display text-xs font-bold block text-slate-900 group-hover:underline">Scan QR-9K2L</span>
                </button>
                <button
                  onClick={() => onSimulateScan('QR-5T7S')}
                  className="p-3 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl text-center group transition-all text-slate-800 cursor-pointer"
                >
                  <Car size={16} className="mx-auto text-blue-600 mb-1" />
                  <span className="font-mono text-[10px] font-bold block text-slate-400">Toyota RAV4</span>
                  <span className="font-display text-xs font-bold block text-slate-900 group-hover:underline">Scan QR-5T7S</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-24 bg-white border-b border-slate-200">
        <div className="max-w-5xl mx-auto px-6">
          <div className="text-center max-w-xl mx-auto mb-16">
            <h2 className="font-display text-3xl font-black text-slate-900 tracking-tight uppercase">
              How Autoscan Works
            </h2>
            <p className="text-sm text-slate-500 mt-2">
              Four steps from registration to secure real-world protection. No complex setups needed.
            </p>
          </div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: '-100px' }}
            className="grid grid-cols-1 md:grid-cols-4 gap-8"
          >
            {/* Step 1 */}
            <motion.div variants={itemVariants} className="space-y-4">
              <div className="w-11 h-11 bg-slate-50 border-2 border-slate-900 rounded-xl flex items-center justify-center font-display text-sm font-black text-slate-900 shadow-sm">
                01
              </div>
              <h3 className="font-display font-bold text-slate-900 text-lg uppercase tracking-tight">Add Vehicle</h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                Add your vehicle details like make, color, model, and license plate into your secure personal dashboard.
              </p>
            </motion.div>

            {/* Step 2 */}
            <motion.div variants={itemVariants} className="space-y-4">
              <div className="w-11 h-11 bg-slate-50 border-2 border-slate-900 rounded-xl flex items-center justify-center font-display text-sm font-black text-slate-900 shadow-sm">
                02
              </div>
              <h3 className="font-display font-bold text-slate-900 text-lg uppercase tracking-tight">Generate QR</h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                Unlock or generate a heavy-duty customized QR code tag mapped directly to your specific vehicle ID.
              </p>
            </motion.div>

            {/* Step 3 */}
            <motion.div variants={itemVariants} className="space-y-4">
              <div className="w-11 h-11 bg-slate-50 border-2 border-slate-900 rounded-xl flex items-center justify-center font-display text-sm font-black text-slate-900 shadow-sm">
                03
              </div>
              <h3 className="font-display font-bold text-slate-900 text-lg uppercase tracking-tight">Stick Tag</h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                Print your dynamic window tag, or download it right to your lock screen. Ideal for dashboard placement.
              </p>
            </motion.div>

            {/* Step 4 */}
            <motion.div variants={itemVariants} className="space-y-4">
              <div className="w-11 h-11 bg-slate-50 border-2 border-slate-900 rounded-xl flex items-center justify-center font-display text-sm font-black text-slate-900 shadow-sm">
                04
              </div>
              <h3 className="font-display font-bold text-slate-900 text-lg uppercase tracking-tight">Get Alerts</h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                Bystanders scan to report blocking or hazards. We alert you instantly while preserving absolute contact privacy.
              </p>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-24 bg-slate-50 border-b border-slate-200">
        <div className="max-w-5xl mx-auto px-6">
          <div className="text-center max-w-xl mx-auto mb-16">
            <h2 className="font-display text-3xl font-black text-slate-900 tracking-tight uppercase">
              Transparent, simple pricing
            </h2>
            <p className="text-sm text-slate-500 mt-2">
              Start protecting your vehicle for free, or upgrade anytime for full coverage.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-3xl mx-auto">
            {/* Free Plan */}
            <div className="bg-white border border-slate-200 rounded-2xl p-8 flex flex-col justify-between shadow-sm hover:shadow-md transition-all">
              <div>
                <span className="text-[10px] font-mono tracking-wider font-extrabold uppercase text-slate-400">
                  Basic Protection
                </span>
                <h3 className="font-display text-2xl font-black text-slate-900 mt-1 uppercase tracking-tight">Free Tier</h3>
                <div className="mt-4 flex items-baseline">
                  <span className="text-4xl font-display font-black tracking-tight text-slate-950">$0</span>
                  <span className="text-slate-400 text-sm font-semibold ml-1">forever</span>
                </div>
                <p className="text-xs text-slate-500 leading-relaxed mt-4">
                  Essential tools for individual owners who want a straightforward, privacy-focused security channel.
                </p>

                <ul className="mt-8 space-y-4 text-xs text-slate-600 border-t border-slate-100 pt-6 font-medium">
                  <li className="flex items-center gap-2.5">
                    <ShieldCheck className="text-slate-400" size={16} />
                    <span>1 Registered Vehicle</span>
                  </li>
                  <li className="flex items-center gap-2.5">
                    <ShieldCheck className="text-slate-400" size={16} />
                    <span>1 Standard Printable QR Code</span>
                  </li>
                  <li className="flex items-center gap-2.5">
                    <ShieldCheck className="text-slate-400" size={16} />
                    <span>Real-time Email Alerts</span>
                  </li>
                  <li className="flex items-center gap-2.5">
                    <ShieldCheck className="text-slate-400" size={16} />
                    <span>Location Tagging (Accuracy 15m)</span>
                  </li>
                </ul>
              </div>

              <button
                onClick={onStart}
                className="mt-8 w-full py-2.5 border-2 border-slate-900 bg-slate-50 hover:bg-slate-100 text-slate-900 text-xs font-black uppercase tracking-wider rounded-lg shadow-sm transition-all cursor-pointer"
              >
                Sign Up Free
              </button>
            </div>

            {/* Pro Plan */}
            <div className="bg-white border-2 border-slate-900 rounded-2xl p-8 flex flex-col justify-between shadow-sm relative overflow-hidden">
              <div className="absolute top-4 right-4 px-2.5 py-1 text-[10px] font-mono font-bold uppercase bg-indigo-600 text-white rounded-md tracking-wider">
                Recommended
              </div>

              <div>
                <span className="text-[10px] font-mono tracking-wider font-extrabold uppercase text-indigo-500">
                  Total Shield
                </span>
                <h3 className="font-display text-2xl font-black text-slate-900 mt-1 uppercase tracking-tight">Pro premium</h3>
                <div className="mt-4 flex items-baseline">
                  <span className="text-4xl font-display font-black tracking-tight text-slate-950">$5</span>
                  <span className="text-slate-400 text-sm font-semibold ml-1">/ month</span>
                </div>
                <p className="text-xs text-slate-500 leading-relaxed mt-4">
                  Advanced alert channels, SMS callbacks, priority notification support, and custom printable styles.
                </p>

                <ul className="mt-8 space-y-4 text-xs text-slate-600 border-t border-slate-100 pt-6 font-semibold">
                  <li className="flex items-center gap-2.5">
                    <ShieldCheck className="text-indigo-600" size={16} />
                    <span className="text-slate-900 font-bold">Unlimited Vehicles Registered</span>
                  </li>
                  <li className="flex items-center gap-2.5">
                    <ShieldCheck className="text-indigo-600" size={16} />
                    <span className="text-slate-900 font-bold">Unlimited QR Tag Codes</span>
                  </li>
                  <li className="flex items-center gap-2.5">
                    <ShieldCheck className="text-indigo-600" size={16} />
                    <span className="text-slate-900 font-bold">Instant SMS Callback Alerts</span>
                  </li>
                  <li className="flex items-center gap-2.5">
                    <ShieldCheck className="text-indigo-600" size={16} />
                    <span>Custom vector SVG download</span>
                  </li>
                </ul>
              </div>

              <button
                onClick={onStart}
                className="mt-8 w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black uppercase tracking-wider rounded-lg shadow-sm transition-all cursor-pointer"
              >
                Get Pro Shield Now
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* CTA section (Spacious card) */}
      <section className="py-24 bg-white">
        <div className="max-w-4xl mx-auto px-6">
          <div className="bg-slate-900 text-white rounded-3xl p-8 sm:p-12 text-center relative overflow-hidden">
            <div className="relative z-10 max-w-xl mx-auto">
              <h2 className="font-display text-3xl sm:text-4xl font-black tracking-tighter uppercase">
                Secure your vehicle today
              </h2>
              <p className="text-xs sm:text-sm text-slate-400 mt-3 leading-relaxed font-semibold">
                No phone number disclosure, no complicated tracking, full integration. Join thousands of drivers avoiding municipal towing fees and disputes.
              </p>
              <button
                id="cta-enroll-btn"
                onClick={onStart}
                className="mt-8 px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold text-xs tracking-wider uppercase transition-all shadow-md inline-flex items-center gap-2 cursor-pointer"
              >
                Access Dashboard <ArrowRight size={16} />
              </button>
            </div>
            {/* Minimal backdrop visual glow */}
            <div className="absolute -bottom-20 -right-20 w-80 h-80 bg-indigo-900 rounded-full blur-[80px] opacity-40"></div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-12 text-center text-slate-400">
        <p className="font-display font-black text-slate-900 uppercase tracking-tighter text-lg">AUTOSCAN<span className="text-slate-400">V1</span></p>
        <p className="text-[11px] font-mono mt-2">&copy; {new Date().getFullYear()} AUTOSCAN, Inc. All rights reserved.</p>
      </footer>
    </div>
  );
}
