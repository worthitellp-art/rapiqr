/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AlertTriangle, Info, PhoneCall, CheckCircle2, Navigation, Send, Loader2, MapPin, ShieldAlert } from 'lucide-react';
import { Vehicle, Report } from '../types';

interface PublicScanPageProps {
  qrCodeId: string;
  vehicles: Vehicle[];
  onSubmitReport: (report: Omit<Report, 'id' | 'createdAt' | 'status'>) => void;
  onNavigateHome: () => void;
}

export default function PublicScanPage({ qrCodeId, vehicles, onSubmitReport, onNavigateHome }: PublicScanPageProps) {
  const vehicle = vehicles.find((v) => v.qrCodeUrl === qrCodeId || v.id === qrCodeId);
  
  const [reportType, setReportType] = useState<'accident' | 'wrong_parking' | 'contact_owner'>('wrong_parking');
  const [message, setMessage] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  
  // Geolocation state
  const [locationState, setLocationState] = useState<{
    loading: boolean;
    coords: { lat: number; lng: number } | null;
    error: string | null;
  }>({
    loading: false,
    coords: null,
    error: null,
  });

  // Attempt to capture location on mount
  useEffect(() => {
    if (navigator.geolocation) {
      setLocationState((prev) => ({ ...prev, loading: true }));
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocationState({
            loading: false,
            coords: {
              lat: position.coords.latitude,
              lng: position.coords.longitude,
            },
            error: null,
          });
        },
        (error) => {
          let errMsg = 'Failed to acquire location';
          if (error.code === error.PERMISSION_DENIED) {
            errMsg = 'Location permission denied by user browser';
          }
          setLocationState({
            loading: false,
            coords: {
              // Fallback fallback: Simulated standard downtown coordinates
              lat: 37.7749 + (Math.random() - 0.5) * 0.01,
              lng: -122.4194 + (Math.random() - 0.5) * 0.01,
            },
            error: errMsg,
          });
        },
        { enableHighAccuracy: true, timeout: 5000 }
      );
    } else {
      setLocationState({
        loading: false,
        coords: { lat: 37.7749, lng: -122.4194 },
        error: 'Geolocation is not supported by your browser',
      });
    }
  }, []);

  if (!vehicle) {
    return (
      <div id="not-found-screen" className="min-h-screen bg-slate-50 flex items-center justify-center p-6 font-sans">
        <div className="max-w-md w-full bg-white border-2 border-slate-900 rounded-2xl p-8 shadow-md text-center">
          <div className="mx-auto w-16 h-16 bg-red-50 text-red-600 rounded-full flex items-center justify-center mb-6 border border-red-200">
            <ShieldAlert size={28} />
          </div>
          <h2 className="font-display text-2xl font-black text-slate-900 mb-2 uppercase tracking-tight">Invalid Tag Code</h2>
          <p className="text-slate-500 text-sm mb-6">
            This QR code is either unregistered or hasn't been assigned to a vehicle yet.
          </p>
          <button
            id="back-home-btn"
            onClick={onNavigateHome}
            className="w-full py-2.5 px-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-bold transition-all uppercase tracking-wider text-xs"
          >
            Go to Platform Home
          </button>
        </div>
      </div>
    );
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate short submission delay for realism
    setTimeout(() => {
      onSubmitReport({
        vehicleId: vehicle.id,
        vehicleLabel: `${vehicle.color} ${vehicle.make} ${vehicle.model}`,
        licensePlate: vehicle.licensePlate,
        type: reportType,
        message: message || `Alert created via scanning tag ${qrCodeId}.`,
        location: locationState.coords,
        reporterPhone: phoneNumber || undefined,
      });
      setIsSubmitting(false);
      setSubmitted(true);
    }, 1200);
  };

  return (
    <div id="public-qr-scan-container" className="min-h-screen bg-slate-50 flex flex-col justify-between font-sans">
      {/* Header banner */}
      <header className="bg-white border-b border-slate-200 py-4 px-6 md:px-8">
        <div className="max-w-lg mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="text-indigo-600 font-black text-xl tracking-tighter uppercase">
              AUTOSCAN<span className="text-slate-400 font-semibold text-xs">V1</span>
            </div>
          </div>
          <div className="px-2.5 py-1 rounded-full bg-slate-100 text-slate-600 font-mono text-xs font-bold uppercase tracking-wider">
            Tag: {qrCodeId}
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-grow py-8 px-4 flex justify-center items-center">
        <div className="w-full max-w-lg bg-white border-2 border-slate-900 rounded-2xl shadow-md overflow-hidden">
          <AnimatePresence mode="wait">
            {!submitted ? (
              <motion.div
                key="form"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                className="p-6 sm:p-8"
              >
                {/* Vehicle Header Information Card */}
                <div id="vehicle-scanned-card" className="bg-slate-50 border border-slate-200 rounded-xl p-4 mb-6">
                  <span className="text-[10px] font-mono tracking-widest uppercase text-slate-400 font-black block mb-1">
                    Scanned Vehicle
                  </span>
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-display text-lg font-black text-slate-900 uppercase tracking-tight">
                        {vehicle.color} {vehicle.make} {vehicle.model}
                      </h3>
                      <p className="text-xs text-slate-500 font-mono mt-0.5 font-semibold">
                        Plate: {vehicle.licensePlate} &bull; Year: {vehicle.year}
                      </p>
                    </div>
                    <span className="inline-flex items-center px-2 py-1 rounded-md text-xs font-black font-mono bg-slate-900 text-white border border-slate-800 uppercase tracking-wider text-[9px]">
                      🔒 Secured
                    </span>
                  </div>
                </div>

                {/* Location Detection Box */}
                <div id="location-capture-box" className="mb-6 flex items-center justify-between p-3 rounded-lg border-2 border-slate-100 bg-white text-slate-700 text-xs">
                  <div className="flex items-center gap-2 font-semibold">
                    <MapPin size={16} className={locationState.coords ? "text-indigo-600" : "text-slate-400 animate-pulse"} />
                    <span className="text-slate-600">
                      {locationState.loading
                        ? 'Acquiring GPS...'
                        : locationState.coords
                        ? 'Secure Location Tagged'
                        : 'GPS Location Tagged (Simulated)'}
                    </span>
                  </div>
                  <div className="font-mono text-[10px] text-slate-500 bg-slate-100 px-2 py-0.5 rounded font-semibold">
                    {locationState.coords
                      ? `${locationState.coords.lat.toFixed(4)}, ${locationState.coords.lng.toFixed(4)}`
                      : 'Simulated Fix'}
                  </div>
                </div>

                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Option List Buttons */}
                  <div>
                    <label className="block text-[10px] font-black uppercase tracking-wider text-slate-500 mb-2.5">
                      Select Alert Category
                    </label>
                    <div className="grid grid-cols-1 gap-2.5">
                      {/* WRONG PARKING BUTTON */}
                      <button
                        type="button"
                        id="option-wrong-parking"
                        onClick={() => setReportType('wrong_parking')}
                        className={`flex items-start gap-3.5 p-4 rounded-xl border-2 text-left transition-all cursor-pointer ${
                          reportType === 'wrong_parking'
                            ? 'bg-amber-50/60 border-amber-500 ring-1 ring-amber-500/30'
                            : 'bg-white border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        <div className={`p-2 rounded-lg mt-0.5 ${reportType === 'wrong_parking' ? 'bg-amber-500 text-white' : 'bg-slate-100 text-slate-500'}`}>
                          <Navigation size={18} className="transform rotate-45" />
                        </div>
                        <div className="flex-grow">
                          <span className="font-display font-black text-slate-900 block text-sm uppercase tracking-tight">
                            🚗 Wrong Parking / Blocking
                          </span>
                          <span className="text-xs text-slate-500 font-medium leading-normal mt-0.5 block">
                            Blockage, driveway obstruction, emergency access, double-parking, or general inconvenience.
                          </span>
                        </div>
                      </button>

                      {/* ACCIDENT ALERT BUTTON */}
                      <button
                        type="button"
                        id="option-accident"
                        onClick={() => setReportType('accident')}
                        className={`flex items-start gap-3.5 p-4 rounded-xl border-2 text-left transition-all cursor-pointer ${
                          reportType === 'accident'
                            ? 'bg-red-50/60 border-red-500 ring-1 ring-red-500/30'
                            : 'bg-white border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        <div className={`p-2 rounded-lg mt-0.5 ${reportType === 'accident' ? 'bg-red-500 text-white' : 'bg-slate-100 text-slate-500'}`}>
                          <AlertTriangle size={18} />
                        </div>
                        <div className="flex-grow">
                          <span className="font-display font-black text-slate-900 block text-sm uppercase tracking-tight">
                            🚨 Vehicle Hazard / Accident
                          </span>
                          <span className="text-xs text-slate-500 font-medium leading-normal mt-0.5 block">
                            Scrapes, break-ins, visual damage, flat tire, open windows, lights left on, or hazard warnings.
                          </span>
                        </div>
                      </button>

                      {/* GENERAL CONTACT BUTTON */}
                      <button
                        type="button"
                        id="option-contact-owner"
                        onClick={() => setReportType('contact_owner')}
                        className={`flex items-start gap-3.5 p-4 rounded-xl border-2 text-left transition-all cursor-pointer ${
                          reportType === 'contact_owner'
                            ? 'bg-indigo-50 border-indigo-600 ring-1 ring-indigo-500/20'
                            : 'bg-white border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        <div className={`p-2 rounded-lg mt-0.5 ${reportType === 'contact_owner' ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-500'}`}>
                          <PhoneCall size={18} />
                        </div>
                        <div className="flex-grow">
                          <span className="font-display font-black text-slate-900 block text-sm uppercase tracking-tight">
                            📞 Request Owner Callback
                          </span>
                          <span className="text-xs text-slate-500 font-medium leading-normal mt-0.5 block">
                            General emergency, keys lock-in, towing request, or direct query to speak with driver.
                          </span>
                        </div>
                      </button>
                    </div>
                  </div>

                  {/* Explanation text input */}
                  <div>
                    <label htmlFor="report-message" className="block text-[10px] font-black uppercase tracking-wider text-slate-500 mb-1.5">
                      Your Message <span className="text-slate-400 font-normal">(Optional)</span>
                    </label>
                    <textarea
                      id="report-message"
                      rows={3}
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder={
                        reportType === 'wrong_parking'
                          ? 'Example: Hey! Your car is slightly blocking driveway #14, please adjust.'
                          : reportType === 'accident'
                          ? 'Example: I noticed your passenger window was rolled down completely.'
                          : 'Enter your short message or request to the vehicle owner details.'
                      }
                      className="w-full px-3.5 py-2.5 text-slate-800 text-sm border-2 border-slate-200 rounded-lg placeholder-slate-400 focus:outline-none focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 resize-none font-medium"
                    ></textarea>
                  </div>

                  {/* Reporter mobile number */}
                  <div>
                    <label htmlFor="reporter-phone" className="block text-[10px] font-black uppercase tracking-wider text-slate-500 mb-1.5">
                      Your Phone Number <span className="text-slate-400 font-normal">(Optional)</span>
                    </label>
                    <input
                      id="reporter-phone"
                      type="tel"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      placeholder="e.g. +1 (555) 0123"
                      className="w-full px-3.5 py-2.5 text-slate-800 text-sm border-2 border-slate-200 rounded-lg placeholder-slate-400 focus:outline-none focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 font-medium"
                    />
                    <span className="block text-[10px] text-slate-400 mt-1.5 leading-normal font-semibold">
                      🛡️ Your details are transferred securely. The owner will see this issue without directly exposing either party's personal phone number.
                    </span>
                  </div>

                  {/* Submit button */}
                  <button
                    type="submit"
                    id="submit-alert-btn"
                    disabled={isSubmitting}
                    className="w-full py-3 px-4 bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-400 text-white rounded-lg text-sm font-bold flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer uppercase tracking-wider"
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 size={16} className="animate-spin" />
                        Relaying Alert Securely...
                      </>
                    ) : (
                      <>
                        <Send size={16} />
                        Send Secured Alert
                      </>
                    )}
                  </button>
                </form>
              </motion.div>
            ) : (
              <motion.div
                key="success"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="p-8 text-center"
              >
                <div className="mx-auto w-14 h-14 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mb-6">
                  <CheckCircle2 size={32} />
                </div>
                <h2 className="font-display text-2xl font-black text-slate-900 mb-2 uppercase tracking-tight">Alert Dispatched</h2>
                <p className="text-sm text-slate-600 leading-relaxed max-w-sm mx-auto mb-6 font-medium">
                  We have instantly notified the owner of the <span className="font-bold text-slate-950">{vehicle.color} {vehicle.make}</span> via instant mobile push. The owner can inspect the action details without showing your phone number.
                </p>
                <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 max-w-sm mx-auto text-left flex items-start gap-2.5 mb-8">
                  <Info size={16} className="text-slate-500 mt-0.5 shrink-0" />
                  <p className="text-xs text-slate-500 leading-normal font-medium">
                    Thank you for being an exceptional community member! Direct communication keeps neighborhoods friendly and car parks safe.
                  </p>
                </div>
                <div className="flex flex-col gap-2.5 max-w-sm mx-auto">
                  <button
                    id="simulate-another-btn"
                    onClick={() => {
                      setSubmitted(false);
                      setMessage('');
                      setPhoneNumber('');
                    }}
                    className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-lg transition-all cursor-pointer uppercase tracking-wider"
                  >
                    Send Another Notice
                  </button>
                  <button
                    id="success-home-btn"
                    onClick={onNavigateHome}
                    className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-lg tracking-wider shadow-sm transition-all cursor-pointer uppercase"
                  >
                    Go to Platform Home
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>

      {/* Footer copyright */}
      <footer className="py-6 text-center border-t border-slate-200 bg-white">
        <p className="text-slate-400 font-mono text-[10px]">
          &copy; {new Date().getFullYear()} AUTOSCAN Inc. Powered by SecureScan protocols.
        </p>
      </footer>
    </div>
  );
}
